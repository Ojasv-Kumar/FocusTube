(() => {
  if (window.__FOCUSTUBE_ATTENTION__) return;
  window.__FOCUSTUBE_ATTENTION__ = true;
  const namespace = "focustube.camera";
  let activeMode = "relax", cameraEnabled = false, video = null, heartbeat = 0, observer = null, gesturePaused = false, lastState = "", warningHost = null, audioContext = null;
  const activeAlerts = new Set();

  function onWatchPage() { return location.pathname === "/watch" && Boolean(new URL(location.href).searchParams.get("v")); }
  function currentVideo() { return document.querySelector("video.html5-main-video") || document.querySelector("ytd-player video") || document.querySelector("video"); }
  function tellWorker() {
    const candidate = currentVideo();
    if (candidate !== video) {
      if (video) { video.removeEventListener("play", handlePlaybackStarted); video.removeEventListener("pause", tellWorker); video.removeEventListener("ended", tellWorker); }
      video = candidate;
      if (video) { video.addEventListener("play", handlePlaybackStarted); video.addEventListener("pause", tellWorker); video.addEventListener("ended", tellWorker); }
    }
    if (video && !video.paused && !video.ended) gesturePaused = false;
    const visible = document.visibilityState === "visible" && document.hasFocus();
    const isPlaying = Boolean(onWatchPage() && video && !video.paused && !video.ended && video.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA);
    if (!isPlaying && !(gesturePaused && onWatchPage() && visible)) gesturePaused = false;
    const payload = { isWatch: onWatchPage(), isPlaying, gesturePaused, visible, mode: activeMode, cameraEnabled, url: location.href };
    const key = JSON.stringify(payload);
    if (key === lastState) return;
    lastState = key;
    try { chrome.runtime.sendMessage({ namespace, type: "PLAYBACK_STATE", payload }); } catch { /* Extension may be reloading. */ }
  }

  function clearWarning() { warningHost?.remove(); warningHost = null; }
  function handlePlaybackStarted() {
    if (warningHost) { activeAlerts.clear(); clearWarning(); }
    gesturePaused = false; lastState = ""; tellWorker();
  }
  function chime() {
    try {
      audioContext ||= new AudioContext();
      if (audioContext.state === "suspended") void audioContext.resume();
      const start = audioContext.currentTime;
      for (const [index, frequency] of [660, 880].entries()) {
        const oscillator = audioContext.createOscillator(), gain = audioContext.createGain();
        oscillator.type = "sine"; oscillator.frequency.value = frequency;
        gain.gain.setValueAtTime(0.0001, start + index * 0.14); gain.gain.exponentialRampToValueAtTime(0.035, start + index * 0.14 + 0.02); gain.gain.exponentialRampToValueAtTime(0.0001, start + index * 0.14 + 0.13);
        oscillator.connect(gain); gain.connect(audioContext.destination); oscillator.start(start + index * 0.14); oscillator.stop(start + index * 0.14 + 0.14);
      }
    } catch { /* Browser autoplay policy may mute the optional chime. */ }
  }
  function showWarning(kind) {
    if (!onWatchPage() || !video || document.visibilityState !== "visible") return;
    if (warningHost) return;
    const text = kind === "camera-error" ? "Camera monitoring stopped. Check camera permission and setup in Settings." : kind === "face-missing" ? "Your face moved out of view. Return to the screen, then resume when you are ready." : "You have been looking away. Return to the screen, then resume when you are ready.";
    warningHost = document.createElement("div");
    warningHost.setAttribute("role", "alertdialog");
    warningHost.setAttribute("aria-live", "assertive");
    warningHost.style.cssText = "all:initial;position:fixed;z-index:2147483647;inset:0;display:grid;place-items:center;padding:24px;pointer-events:none;";
    const shadow = warningHost.attachShadow({ mode: "closed" }), card = document.createElement("section"), heading = document.createElement("h2"), message = document.createElement("p"), resume = document.createElement("button");
    card.style.cssText = "box-sizing:border-box;width:min(680px,calc(100vw - 48px));padding:34px 38px;border:1px solid #c7ec9c;border-radius:22px;background:#151b18;color:#f3f6f2;box-shadow:0 24px 80px #000b;text-align:center;font:600 18px/1.55 system-ui,sans-serif;pointer-events:none";
    heading.textContent = kind === "camera-error" ? "Camera check needed" : "Take a moment to refocus";
    heading.style.cssText = "margin:0 0 14px;font:750 clamp(28px,5vw,40px)/1.1 system-ui,sans-serif;letter-spacing:-.035em;color:#f3f6f2";
    message.textContent = text;
    message.style.cssText = "margin:0 auto 26px;max-width:52ch;color:#c4cbc4;font:500 clamp(17px,2.5vw,21px)/1.5 system-ui,sans-serif";
    resume.type = "button"; resume.textContent = "Resume video"; resume.setAttribute("aria-label", "Resume the paused video and close the FocusTube alert");
    resume.style.cssText = "border:0;border-radius:12px;padding:13px 20px;background:#a9e66e;color:#17200f;font:750 17px system-ui,sans-serif;cursor:pointer;pointer-events:auto";
    resume.addEventListener("click", () => { if (video?.paused) void video.play().catch(() => {}); else handlePlaybackStarted(); });
    card.append(heading, message, resume); shadow.append(card); (document.body || document.documentElement).append(warningHost); chime();
    if (!video.paused) video.pause();
    gesturePaused = false; lastState = ""; tellWorker();
  }
  function toggleFromGesture() {
    if (!onWatchPage() || !video || document.visibilityState !== "visible") return;
    if (video.paused) {
      gesturePaused = false;
      const result = video.play(); if (result?.catch) result.catch(() => {});
    } else { gesturePaused = true; video.pause(); }
    lastState = ""; tellWorker();
  }

  chrome.runtime.onMessage.addListener(message => {
    if (message?.namespace !== namespace) return false;
    if (message.type === "ATTENTION_ALERT") { activeAlerts.add(message.payload?.kind); showWarning(message.payload?.kind); }
    if (message.type === "ATTENTION_CLEAR" && !warningHost) {
      if (message.payload?.kind) activeAlerts.delete(message.payload.kind); else activeAlerts.clear();
      if (!activeAlerts.size) clearWarning();
    }
    if (message.type === "ATTENTION_GESTURE") toggleFromGesture();
    if (message.type === "CAMERA_ERROR") {
      activeAlerts.clear(); showWarning("camera-error");
    }
    return false;
  });

  chrome.storage.local.get(["activeMode", "cameraEnabled"], values => { activeMode = values.activeMode || "relax"; cameraEnabled = values.cameraEnabled === true; tellWorker(); });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes.activeMode) activeMode = changes.activeMode.newValue || "relax";
    if (changes.cameraEnabled) cameraEnabled = changes.cameraEnabled.newValue === true;
    lastState = ""; if (activeMode !== "learn" || !cameraEnabled) gesturePaused = false;
    tellWorker();
  });
  for (const event of ["yt-navigate-start", "yt-navigate-finish", "popstate", "focus", "blur"]) window.addEventListener(event, () => { lastState = ""; if (!onWatchPage()) { gesturePaused = false; clearWarning(); } tellWorker(); });
  document.addEventListener("visibilitychange", () => { lastState = ""; tellWorker(); });
  observer = new MutationObserver(() => { if (!video?.isConnected || !currentVideo()) tellWorker(); });
  observer.observe(document.documentElement, { childList: true, subtree: true });
  heartbeat = setInterval(() => { lastState = ""; tellWorker(); }, 1500);
  window.addEventListener("pagehide", () => { clearInterval(heartbeat); observer?.disconnect(); warningHost?.remove(); try { chrome.runtime.sendMessage({ namespace, type: "PLAYBACK_STATE", payload: { isWatch: false, isPlaying: false, gesturePaused: false, visible: false, mode: activeMode, cameraEnabled: false, url: location.href } }); } catch {} }, { once: true });
  tellWorker();
})();
