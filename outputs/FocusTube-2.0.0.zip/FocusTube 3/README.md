# FocusTube

Unpacked release folder for FocusTube 2.0.0. It contains only the extension manifest and runtime files.

1. Open `brave://extensions/` (or `chrome://extensions/`) and enable Developer mode.
2. Choose **Load unpacked** and select this folder.
3. After updating these files, click the extension's **Reload** button and refresh YouTube.

The editable source and tests are in the parent project folder.
