export function faceDirection(landmarks) {
  if (!Array.isArray(landmarks) || landmarks.length < 455) return null;
  const nose = landmarks[1], leftEye = landmarks[33], rightEye = landmarks[263], chin = landmarks[152];
  if (![nose, leftEye, rightEye, chin].every(point => Number.isFinite(point?.x) && Number.isFinite(point?.y))) return null;
  const eyeMidX = (leftEye.x + rightEye.x) / 2, eyeMidY = (leftEye.y + rightEye.y) / 2;
  const eyeWidth = Math.abs(rightEye.x - leftEye.x), faceHeight = Math.abs(chin.y - eyeMidY);
  if (eyeWidth < 0.015 || faceHeight < 0.035) return null;
  return { yaw: (nose.x - eyeMidX) / eyeWidth, pitch: (nose.y - eyeMidY) / faceHeight };
}

export function isAway(direction, calibration, yawLimit = 0.24, pitchLimit = 0.22) {
  if (!direction || !calibration) return false;
  return Math.abs(direction.yaw - calibration.yaw) >= yawLimit || Math.abs(direction.pitch - calibration.pitch) >= pitchLimit;
}

export function isOpenPalm(result) {
  const category = result?.gestures?.[0]?.[0];
  return category?.categoryName === "Open_Palm" && category.score >= 0.72;
}
