(() => {
  if (window.__FOCUSTUBE_ATTENTION__) return;
  window.__FOCUSTUBE_ATTENTION__ = true;
  const namespace = "focustube.camera";
  let activeMode = "relax", cameraEnabled = false, video = null, heartbeat = 0, observer = null, gesturePaused = false, lastState = "", warningHost = null, warningTimer = 0, audioContext = null;
  const activeAlerts = new Set();

  function onWatchPage() { return location.pathname === "/watch" && Boolean(new URL(location.href).searchParams.get("v")); }
  function currentVideo() { return document.querySelector("video.html5-main-video") || document.querySelector("ytd-player video") || document.querySelector("video"); }
  function tellWorker() {
    const candidate = currentVideo();
    if (candidate !== video) { if (video) { video.removeEventListener("play", tellWorker); video.removeEventListener("pause", tellWorker); video.removeEventListener("ended", tellWorker); } video = candidate; if (video) { video.addEventListener("play", tellWorker); video.addEventListener("pause", tellWorker); video.addEventListener("ended", tellWorker); } }
    if (video && !video.paused && !video.ended) gesturePaused = false;
    const visible = document.visibilityState === "visible" && document.hasFocus();
    const isPlaying = Boolean(onWatchPage() && video && !video.paused && !video.ended && video.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA);
    if (!isPlaying && !(gesturePaused && onWatchPage() && visible)) gesturePaused = false;
    const payload = { isWatch: onWatchPage(), isPlaying, gesturePaused, visible, mode: activeMode, cameraEnabled, url: location.href };
    const key = JSON.stringify(payload);
    if (key === lastState) return;
    lastState = key;
    try { chrome.runtime.sendMessage({ namespace, type: "PLAYBACK_STATE", payload }); } catch { /* Extension may be reloading. */ }
  }

  function clearWarning() { if (warningTimer) clearTimeout(warningTimer); warningTimer = 0; warningHost?.remove(); warningHost = null; }
  function chime() {
    try {
      audioContext ||= new AudioContext();
      if (audioContext.state === "suspended") void audioContext.resume();
      const start = audioContext.currentTime;
      for (const [index, frequency] of [660, 880].entries()) {
        const oscillator = audioContext.createOscillator(), gain = audioContext.createGain();
        oscillator.type = "sine"; oscillator.frequency.value = frequency;
        gain.gain.setValueAtTime(0.0001, start + index * 0.14); gain.gain.exponentialRampToValueAtTime(0.035, start + index * 0.14 + 0.02); gain.gain.exponentialRampToValueAtTime(0.0001, start + index * 0.14 + 0.13);
        oscillator.connect(gain); gain.connect(audioContext.destination); oscillator.start(start + index * 0.14); oscillator.stop(start + index * 0.14 + 0.14);
      }
    } catch { /* Browser autoplay policy may mute the optional chime. */ }
  }
  function showWarning(kind) {
    if (!onWatchPage() || !video || video.paused || document.visibilityState !== "visible") return;
    const text = kind === "camera-error" ? "FocusTube: Camera monitoring stopped. Check camera permission and setup in Settings." : kind === "face-missing" ? "FocusTube: Your face is out of view. Take a moment to return to your video." : "FocusTube: You seem to be looking away. Return to the video when you’re ready.";
    clearWarning();
    warningHost = document.createElement("div"); warningHost.style.cssText = "all:initial;position:fixed;z-index:2147483647;top:18px;left:50%;transform:translateX(-50%);max-width:min(560px,calc(100vw - 32px));";
    const shadow = warningHost.attachShadow({ mode: "closed" }), card = document.createElement("div"), message = document.createElement("span"), dismiss = document.createElement("button");
    card.style.cssText = "box-sizing:border-box;display:flex;align-items:center;gap:16px;padding:13px 16px;border:1px solid #c7ec9c;border-radius:14px;background:#151b18;color:#f3f6f2;box-shadow:0 12px 40px #0009;font:600 14px/1.45 system-ui,sans-serif";
    message.textContent = text; dismiss.type = "button"; dismiss.textContent = "Dismiss"; dismiss.setAttribute("aria-label", "Dismiss FocusTube attention alert"); dismiss.style.cssText = "border:0;border-radius:9px;padding:7px 10px;background:#a9e66e;color:#17200f;font:700 13px system-ui;cursor:pointer;white-space:nowrap"; dismiss.addEventListener("click", clearWarning);
    card.append(message, dismiss); shadow.append(card); (document.body || document.documentElement).append(warningHost); chime();
    if (warningTimer) clearTimeout(warningTimer);
    warningTimer = setTimeout(() => { if (warningHost?.isConnected) clearWarning(); }, 9000);
  }
  function toggleFromGesture() {
    if (!onWatchPage() || !video || document.visibilityState !== "visible") return;
    if (video.paused) {
      gesturePaused = false;
      const result = video.play(); if (result?.catch) result.catch(() => {});
    } else { gesturePaused = true; video.pause(); }
    lastState = ""; tellWorker();
  }

  chrome.runtime.onMessage.addListener(message => {
    if (message?.namespace !== namespace) return false;
    if (message.type === "ATTENTION_ALERT") { activeAlerts.add(message.payload?.kind); showWarning(message.payload?.kind); }
    if (message.type === "ATTENTION_CLEAR") {
      if (message.payload?.kind) activeAlerts.delete(message.payload.kind); else activeAlerts.clear();
      if (!activeAlerts.size) clearWarning();
    }
    if (message.type === "ATTENTION_GESTURE") toggleFromGesture();
    if (message.type === "CAMERA_ERROR") {
      activeAlerts.clear(); showWarning("camera-error");
    }
    return false;
  });

  chrome.storage.local.get(["activeMode", "cameraEnabled"], values => { activeMode = values.activeMode || "relax"; cameraEnabled = values.cameraEnabled === true; tellWorker(); });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes.activeMode) activeMode = changes.activeMode.newValue || "relax";
    if (changes.cameraEnabled) cameraEnabled = changes.cameraEnabled.newValue === true;
    lastState = ""; if (activeMode !== "learn" || !cameraEnabled) { clearWarning(); gesturePaused = false; }
    tellWorker();
  });
  for (const event of ["yt-navigate-start", "yt-navigate-finish", "popstate", "focus", "blur"]) window.addEventListener(event, () => { lastState = ""; if (!onWatchPage()) { gesturePaused = false; clearWarning(); } tellWorker(); });
  document.addEventListener("visibilitychange", () => { lastState = ""; if (document.visibilityState !== "visible") clearWarning(); tellWorker(); });
  observer = new MutationObserver(() => { if (!video?.isConnected || !currentVideo()) tellWorker(); });
  observer.observe(document.documentElement, { childList: true, subtree: true });
  heartbeat = setInterval(() => { lastState = ""; tellWorker(); }, 1500);
  window.addEventListener("pagehide", () => { clearInterval(heartbeat); observer?.disconnect(); warningHost?.remove(); try { chrome.runtime.sendMessage({ namespace, type: "PLAYBACK_STATE", payload: { isWatch: false, isPlaying: false, gesturePaused: false, visible: false, mode: activeMode, cameraEnabled: false, url: location.href } }); } catch {} }, { once: true });
  tellWorker();
})();
